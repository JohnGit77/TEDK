const jwt = require('jsonwebtoken');

// Middleware per verificare il token JWT
const authenticate = (req, res, next) => {
    const token = req.header('Authorization')?.split(' ')[1]; // Bearer token

    if (!token) {
        return res.status(401).json({ message: 'Accesso negato. Token mancante.' });
    }

    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        req.user = verified; // Aggiunge i dati utente alla richiesta
        next();
    } catch (error) {
        res.status(400).json({ message: 'Token non valido.' });
    }
};

module.exports = authenticate;
