
const authenticate = require('../middlewares/authenticate');

const router = express.Router();

// Rotta protetta
router.get('/secure', authenticate, (req, res) => {
    res.status(200).json({ message: `Benvenuto, utente con ruolo ${req.user.role}!` });
});

module.exports = router;
