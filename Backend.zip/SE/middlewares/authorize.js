// Middleware per verificare il ruolo
const authorize = (roles) => (req, res, next) => {
    if (!roles.includes(req.user.role)) {
        return res.status(403).json({ message: 'Accesso negato. Privilegi insufficienti.' });
    }
    next();
};

module.exports = authorize;
